<?php

	$user = $_POST["Input_user"];
	$pass = $_POST["Input_pass"];

	//$user = '�ڼ���';
	//$user = iconv('euc-kr', 'utf-8', $user);
	//euc-kr > utf-8
	$user = iconv('utf-8', 'utf-8', $user);
	
	
	$conn=mysqli_connect("localhost","root","1234");
		
	if(mysqli_connect_errno($conn))
	{
		echo "Fail to connect to MYSQL: " . msqli_connect_error();
	}
	mysqli_set_charset($conn,"utf8");
	
	mysqli_select_db($conn, "test");

	$query = "SELECT * FROM User WHERE id='".$user."'";
	
	//echo $query;
	
	$res = mysqli_query($conn, $query);	
	
	$rows = array();
	$result = array();

	while($row = mysqli_fetch_array($res))
	{
		$rows["ID"] = $row[0];//id
		$rows["PASS"] = $row[1];//password
		$rows["NOTE"]= $row[2];//note		
		array_push($result, $rows);
		//php���� echo�� printf �� ���� ������Ѵ�.
		//��� ������� ȭ�鿡 ǥ�����ش�
		//echo $row[0];
	}
	echo json_encode(array("results"=>$result));
	
	mysqli_close($conn);	

?>