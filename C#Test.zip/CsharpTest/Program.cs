﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpTest
{
    class Program
    {
        static void Main(string[] args)
        {
            // 델리게이트와 이벤트를 쓰는 이유
            // 클래스끼리의 변수 참조 디커플링과 동시에
            // 데이터와 UI의 분리를 위해서 사용한다.
            while (true)
            {
                MonsterA monsterA = new MonsterA("Monster_A", 1, 10f, 20);

                Player player = new Player();
                player.Attack_Event += monsterA.Damage;
                player.EnemyKill_Event += player.inven.GetGold;
                monsterA.Attack_Event += player.Damage;

                Console.WriteLine("C# 델리게이트와 이벤트, 추상클레스와 인터페이스 연습입니다.\na키를 눌러주세요");

                ConsoleKeyInfo key = Console.ReadKey();

                if (key.Key == ConsoleKey.A)
                {
                    Console.Clear();
                    Console.WriteLine("플레이어의 이름을 정해주세요");

                    string Name = Console.ReadLine();
                    player.name = Name;

                    Console.Clear();

                    while (monsterA.state == MonsterBase.State.Alive)
                    {
                        Console.WriteLine("b키를 눌러주세요.\n");
                        key = Console.ReadKey();
                        if (key.Key == ConsoleKey.B)
                        {
                            if (monsterA.state != MonsterBase.State.Die)
                            {
                                player.Attack(player.atk);
                                monsterA.Attack(monsterA.atk);
                            }
                            else
                            {
                                player.EnemyKill(monsterA.gold, monsterA.exp);
                            }
                        }
                    }

                    Console.WriteLine("다시 시작하려면 엔터키를 눌러주세요.\n");
                    Console.ReadLine();
                    Console.Clear();
                }
            }
        }

        interface IDamage
        {
            void Damage(int _damage);
        }

        interface IAttack
        {
            void Attack(int _damage);
        }

        class Player : IDamage, IAttack
        {
            public string name;
            int exp = 0;
            public int atk = 5;
            float curHp = 100;

            public delegate void Attack_Del(int _damage);
            public event Attack_Del Attack_Event;

            public delegate void EnemyKill_Del(int _gold, string _name);
            public event EnemyKill_Del EnemyKill_Event;

            public Inven inven = new Inven();

            public void GetExp(int _exp)
            {
                exp += _exp;
                Console.WriteLine("{1}은(는) {0}경험치 획득했다!\n플레이어의 현재 경험치 : {2}\n", _exp, name, exp);
            }

            public void EnemyKill(int _gold, int _exp)
            {
                EnemyKill_Event(_gold, this.name);
                GetExp(_exp);
            }

            public void Damage(int _damage)
            {
                curHp -= _damage;
                Console.WriteLine("{0}은(는) 의 데미지를 입었다.\n플레이어의 현재 채력 : {1}\n", name, curHp);
            }

            public void Attack(int _damage)
            {
                Attack_Event(_damage);
            }
        }

        class Inven
        {
            public int gold = 0;

            public void GetGold(int i, string _name)
            {
                gold += i;
                Console.WriteLine("{1}은(는) {0} 골드 획득했다!\n플레이어의 현재 골드 : {2}\n", i, _name, gold);
            }
        }

        abstract class MonsterBase : IDamage, IAttack
        {
            public enum State
            {
                Alive,
                Die,
            }

            public string name;
            public int level;
            public float maxHp;
            public float curHp;
            public int gold = 10;
            public int exp = 15;
            public int atk;
            public State state = State.Alive;

            public delegate void Attack_Del(int Damage);
            public event Attack_Del Attack_Event;

            public MonsterBase(string _name, int _level, float _maxHp, int _atk)
            {
                name = _name;
                level = _level;
                maxHp = _maxHp;
                curHp = _maxHp;
                atk = _atk;
            }

            public void Damage(int _damage)
            {
                curHp -= _damage;

                if (curHp <= 0)
                {
                    curHp = 0;
                    Console.WriteLine("{3}은(는) {0} 의 데미지를 입음.\n{3}의 현재 Hp : {1}/{2}\n", _damage, curHp, maxHp, name);
                    Console.WriteLine("{0}은(는) 사망했다.\n", name);
                    state = State.Die;
                }
                else
                {
                    Console.WriteLine("{3}은(는) {0} 의 데미지를 입음.\n현재 Hp : {1}/{2}\n", _damage, curHp, maxHp, name);
                }
            }

            public void Attack(int _damage)
            {
                Attack_Event(_damage);
            }
        }

        class MonsterA : MonsterBase
        {
            public MonsterA(string _name, int _level, float _maxHp, int _atk) : base(_name, _level, _maxHp, _atk) { }
        }
    }
}
